module Kindle
  VERSION = "0.1.3"
end
